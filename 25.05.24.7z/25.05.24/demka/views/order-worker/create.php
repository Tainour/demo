<?php

use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var app\models\OrderWorker $model */

$this->title = 'Create Order Worker';
$this->params['breadcrumbs'][] = ['label' => 'Order Workers', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="order-worker-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
